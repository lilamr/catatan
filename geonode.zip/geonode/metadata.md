Metadata merupakan keterangan atau informasi tentang suatu data. Informasi ini disimpan untuk bisa menjelaskan tentang seluk-beluk data tersebut. Pada sistem GeoNode pengguna/user dapat mengisi metadata dengan melakutan edit metadata. Caranya adalah sebagai berikut :
1. Masuk/login dengan menggunakan username dan password akun pengguna/user.
2. Masuk kedalam layer/data spasial yang akan diedit meta datanya.
3. Klik Edit Layer, kemudian pada bagian Metadata klik Edit.
4. Akan tampil form isian Metadata. Isilah bagian-bagian metadata yang menjelaskan informasi rinci terkait tentang data tersebut seperti abstraksi, kategori ,dll.
5. Setelah selesai mengisi informasi tentang data tersebut pada form isian metadata, kita dapat mengklik Update menyimpan hasil editan metadata yang telah kita lakukan.