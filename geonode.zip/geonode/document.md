Seperti halnya Layer dan Map, Document juga merupakan salah satu komponen penting dari sistem GeoNode. Di dalam Document kita dapat menyimpan, mengunggah dan mengunduh dokumen-dokumen baik bentuk teks, tabel, maupun gambar. Format yang didukung oleh GeoNode untuk disimpan dalam Document ini antara lain: .doc, .docx, .gif, .jpg, .jpeg, .ods, .od,t .odp, .pdf, .png, .ppt, .pptx, .rar, .sld, .tif, .tiff, .txt, .xls, .xlsx, .xml, .zip, .gz. Kita dapat mengklik menu Document pada toolbar GeoNode untuk menampilkan dokumen-dokumen yang telah terpublikasi dalam sistem GeoNode.

Sistem GeoNode memungkinkan kita untuk mengunggah dan mengunduh dokumen yang kita punya. Format dokumen yang dimungkinkan untuk diunggah adalah .doc, .docx, .gif, .jpg, .jpeg, .ods, .od,t .odp, .pdf, .png, .ppt, .pptx, .rar, .sld, .tif, .tiff, .txt, .xls, .xlsx, .xml, .zip, .gz. Langkah untuk menggunggah dokumen ke dalam sistem geonode adalah sebagai berikut :
1. Masuk/Sign In ke akun kita yang ada di sistem GeoNode dengan mengisikan username dan passwordnya. Setelah itu klik Upload Documents.
2. Akan muncul tampilan jendela Upload Documents dimana kita dapat memberi judul dokumen yang akan kita unggah, memilih file dokumen, serta mengatur permission untuk dokumen kita. Setelah selesai semua itu kita dapat klik Upload. Tunggu hingga proses pengunggahan selesai.


